<?php
include('include/dbconnection.php');
$result = mysqli_query($con, "SELECT * FROM contact WHERE id='" . $_GET['id'] . "'");
$row = mysqli_fetch_array($result);

?>
<?php

 if (isset($_POST["submit"])) {
        $fullname=($_POST['fullname']); 
        $email=($_POST['email']); 
        $number=($_POST['number']); 
        $subject=($_POST['subject']); 
        

        $query    = "UPDATE  contact set fullname='$fullname',email='$email',number='$number',subject='$subject'";
                     
        $result   = mysqli_query($con, $query);
        
        if ($result) {
            echo "<script>alert('Contact has been updated');</script>";
            ?>
            <script>
                window.location.href='index.php';
            </script>
        <?php } else {
            echo "<script>alert('Contact has been not updated');</script>";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text],input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit],button[type=submit]{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
.btn{
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.btn:hover{
  background-color: #45a049;
  color: white;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>
<nav class="navbar navbar-expand navbar-dark bg-dark static-top">

<a class="navbar-brand mr-1" href="index.html">Laundary Management System</a>


</nav>

<br>
<div class="container">
  <form action="" method="post">
    <label for="fullname">Full Name</label>
    <input type="text" id="fullname" name="fullname" placeholder="FristName MiddleName SurName" required value="<?php echo $row['fullname']; ?>" readonly>

    <label for="Email">Email</label>
    <input type="email" id="email" name="email" placeholder="abc@gmail.com" value="<?php echo $row['email']; ?>" readonly>   
    
    <label for="contact">Mobile Number</label>
    <input type="text" id="mobilenumber" name="number" placeholder="Your number" value="<?php echo $row['number']; ?>" readonly>

    <label for="subject">Subject</label>
    <textarea id="subject" readonly name="subject" placeholder="Write something.." style="height:200px"><?php echo $row['subject']; ?></textarea>

    <a href="contacts.php" class="btn">Back</a>
    
  </form>
</div>

</body>
</html>


<?php
session_start();
error_reporting(0);
include('user/include/dbconnection.php');

     ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Laundary Management System</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  

</head>


</html>

<!DOCTYPE html>

<html>
	<head>
		<title>LMS | Contact us</title>
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
	</head>
	<body>
		<!--start-wrap-->
		
			<!--start-header-->
			<div class="header">
				<div class="wrap">
				<!--start-logo-->
				<div class="logo">
		<a href="index.html" style="font-size: 30px;">Laundary Management System</a> 
				</div>
				<!--end-logo-->
				<!--start-top-nav-->
				<div class="top-nav">
					<ul>
						<li><a href="index.php" style="text-decoration: none;" >Home </a></li>
					
						<li class="active"><a href="price.php" style="text-decoration: none;"> Price</a></li>
					</ul>					
				</div>
				<div class="clear"> </div>
				<!--end-top-nav-->
			</div>
			<!--end-header-->
		</div>
		    <div class="clear"> </div>
		   <div class="wrap">
		   	<div class="contact">
         <?php

$ret=mysqli_query($con,"select * from tblpricelist");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
      <br><br>
<h3 style="text-align: center;font-size: 25px;">Laundry Price(Per Unit)</h3>
       <table border="1" class="table table-bordered mg-b-0  table-hover">
<tr>
    <th>Top Wear Laundry Price</th>
    <td><?php  echo $row['TopWear'];?></td>
  </tr>


   <tr>
    <th>Bootom Wear Laundry Price</th>
    <td><?php  echo $row['BottomWear'];?></td>
  </tr>
 
<tr>
    <th>Woolen Cloth Laundry Price</th>
    <td><?php  echo $row['Woolen'];?></td>
  </tr>
  
 
 
  
 


</table>

  



<?php } ?>
			  	 <div class="clear"> </div>
	</div>
	<div class="clear"> </div>
			</div>
	      <div class="clear"> </div>
		   <div class="footer">
		   	 <div class="wrap">
		   	<div class="footer-left">
		   			<ul>
						<li><a href="index.php">Home</a></li>
						
						<li><a href="contact.php">contact</a></li>
						<li><a href="Price.php">Price</a></li>
					</ul>
		   	</div>
		  
		   	<div class="clear"> </div>
		   </div>
		   </div>
		<!--end-wrap-->
	</body>
</html>

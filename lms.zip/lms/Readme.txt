
Credential for admin panel :
Username: admin
Password: 12
Credential for user panel :
Username: abcxyz@gmail.com
Password: 12

1. Total 6 table
2. tblreviwe & contact tbl name
3. login, reg,forget pass page desing change 
4. template color change 
5. first page chage index page
  